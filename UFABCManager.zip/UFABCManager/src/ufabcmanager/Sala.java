package ufabcmanager;

import jade.core.Agent;

public class Sala extends Agent {
    @Override
    public void setup() 
    {
        System.out.println("Novo agente Sala inicializado.");
    }
    
    @Override
    protected void takeDown()
    {
        
    }
}
